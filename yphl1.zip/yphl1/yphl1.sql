

/* 회원 테이블 */
create table Member (
	M_email VARCHAR2(50) primary key,
	M_name VARCHAR2(50),
	M_tel VARCHAR2(20),
	M_password VARCHAR2(150),
	M_img VARCHAR2(100),
	M_birth DATE,
	M_addr VARCHAR2(200),
	M_addr_detail VARCHAR2(200),
	join_date DATE,
	del CHAR(1) default 'n',
	recommend_code VARCHAR2(50),
	mileage NUMBER(5) default '0'
);

select * from member;
drop table member;
select * from Member where M_tel=01082787504;

/* 상품 테이블 */
create table Product (
	P_no NUMBER(4) primary key,
 	P_group VARCHAR2(100),
  	P_type VARCHAR2(100),
  	P_program VARCHAR2(100),
  	P_name VARCHAR2(100),
  	P_sal NUMBER(10),
  	stock NUMBER(4) default '9999'
);

select * from product;
drop table product;

insert into product(P_no, P_group, P_type, P_program, P_name, P_sal, stock)
 values(1, 1, 1, 1, '하건호', 1, 1);


/* 주문 테이블 */
create table M_order (
	order_no NUMBER(4) primary key,
	M_email VARCHAR2(50) references Member(M_email),
	order_date DATE,
	status VARCHAR2(50) default '상품준비중',
	JU_name VARCHAR2(50),
	JU_tel VARCHAR2(50),
	JU_addr VARCHAR2(50),
	JU_addr_detail VARCHAR2(50),
	SU_name VARCHAR2(50),
	SU_tel VARCHAR2(50),
	SU_addr VARCHAR2(50),
	SU_addr_detail VARCHAR2(50)
);

select * from M_order;
drop table M_order;

insert into M_order(
 order_no, M_email, P_no, order_date, status, JU_name, JU_tel, JU_addr, JU_addr_detail, SU_name, SU_tel, SU_addr, SU_addr_detail)
 values((select nvl(max(order_no), 0)+1 from M_order), 
	     'gunho.ha9207@gmail.com', 1, sysdate, '상품준비중', '하건호', 010-1111-1111, '신촌', '신촌',
	     							    '하건호', 010-2222-2222, '신촌2', '신촌2' );


/* 주문 상세 테이블 */
create table M_order_detail (
	order_detail_no NUMBER(4) primary key,
  	order_quantity NUMBER(4),
  	refund_chk CHAR(1) default 'n',
  	total_price NUMBER(6),
  	order_no NUMBER(4) references M_order(order_no),
  	P_no NUMBER(4) references Product(P_no)
);

select * from M_order_detail;
drop table M_order_detail;


/* 장바구니 테이블 */
create table Cart (
	cart_no NUMBER(4) primary key,
	cart_quantity NUMBER(4),
	M_email VARCHAR2(50) references Member(M_email),
	P_no NUMBER(5) references Product(P_no)
);


select * from Cart;
drop table Cart;


/* 상품문의 테이블 */
create table P_qna (
	P_qna_no NUMBER(4) primary key,
    P_qna_title VARCHAR2(100),
    P_qna_content VARCHAR2(300),
    P_qna_regDate DATE,
    del CHAR(1) default 'n',
    M_email VARCHAR2(50) references Member(M_email),
    P_no NUMBER(4) references Product(P_no)
);

select * from P_qna;
drop table P_qna;


/* 상품문의 댓글 테이블 */
create table P_qna_re (
	P_qna_re_no NUMBER(4) primary key,
    P_qna_re_content VARCHAR2(300),
    P_qna_re_regDate DATE,
    P_qna_re_del CHAR(1) default 'n',
    M_email VARCHAR2(50) references Member(M_email),
    P_qna_no NUMBER(4) references P_qna(P_qna_no)
);

select * from P_qna_re;
drop table P_qna_re;


/* 리뷰 테이블 */
create table Review (
	RV_no NUMBER(4) primary key,
    RV_star NUMBER(5),
    RV_content VARCHAR2(300),
    RV_regDate DATE,
    del CHAR(1) default 'n',
    P_no NUMBER(4) references Product(P_no),
    M_email VARCHAR2(50) references Member(M_email)
);

select * from Review;
drop table Review;


/* 위시리스트(찜) 테이블 */
create table WishList (
	wish_no NUMBER(4) primary key,
    P_no NUMBER(4) references Product(P_no),
    M_email VARCHAR2(50) references Member(M_email)
);

select * from WishList;
drop table WishList;


/* QnA(1:1문의) 테이블 */
create table QnA (
	QA_no NUMBER(4) primary key,
    QA_subject VARCHAR2(100),
    QA_content VARCHAR2(500),
    reg_date DATE,
    QA_condition VARCHAR2(30) default '답변 대기',
    QA_del CHAR(1) default 'n',
    M_email VARCHAR2(50) references Member(M_email)
);

select * from QnA;
drop table QnA;

/* 쿠폰 테이블 */
create table Coupon (
	coupon_no NUMBER(4) primary key,
    coupon_type VARCHAR2(30),
    coupon_use CHAR(1) default 'n',
    coupon_order_no NUMBER(4),
    coupon_max_date DATE,
    coupon_status NUMBER(10),
    coupon_ratio NUMBER(4,2),
    max_value NUMBER(6),
    use_min_price NUMBER(4),
    M_email VARCHAR2(50) references Member(M_email),
    order_detail_no NUMBER(4) references M_order_detail(order_detail_no)
);

select * from Coupon;
drop table Coupon;


/* 환불 테이블  */
create table Refund (
	refund_no NUMBER(4) primary key,
    reason VARCHAR2(300),
    M_email VARCHAR2(50) references Member(M_email),
    order_detail_no NUMBER(4) references M_order_detail(order_detail_no)
);

select * from Refund;
drop table Refund;


/* 제휴서비스 테이블 */
create table Affi (
	AF_no NUMBER(4) primary key,
    AF_name VARCHAR2(30),
    AF_tel VARCHAR2(30),
    AF_email VARCHAR2(50),
    AF_title VARCHAR2(30),
    AF_content VARCHAR2(500),
    AF_file VARCHAR2(100)
);

select * from Affi;
drop table Affi;


/* 메거진(공지사항) 테이블 */
create table Magazine (
	MG_no NUMBER(4) primary key,
    MG_title VARCHAR2(50),
    MG_content VARCHAR2(1000),
    MG_regDate DATE,
    MG_img VARCHAR2(100)
);

select * from Magazine;
drop table Magazine;

insert into Product(P_no, P_group, P_type, P_program, P_name, P_sal, stock) 
values(1, 'subsciption', 'yummy', 20, '[Yummy line] 맛있어라인 - 1일 1식 20일 프로그램', 179000, 9999);
insert into Product(P_no, P_group, P_type, P_program, P_name, P_sal, stock) 
values(2, 'subsciption', 'yummy', 10, '[Yummy line] 맛있어라인 - 1일 1식 10일 프로그램', 92100, 9999);
insert into Product(P_no, P_group, P_type, P_program, P_name, P_sal, stock) 
values(3, 'subsciption', 'yummy', 4, '[Yummy line] 맛있어라인 - 1일 1식 4일 프로그램', 36900, 9999);
insert into Product(P_no, P_group, P_type, P_program, P_name, P_sal, stock) 
values(4, 'subsciption', 'original', 4, '[Original line] 1일 1식 4일 프로그램', 36900, 9999);
insert into Product(P_no, P_group, P_type, P_program, P_name, P_sal, stock) 
values(5, 'subsciption', 'original', 10, '[Original line] 1일 1식 10일 프로그램', 92100, 9999);
insert into Product(P_no, P_group, P_type, P_program, P_name, P_sal, stock) 
values(6, 'subsciption', 'original', 20, '[Original line] 1일 1식 20일 프로그램', 179000, 9999);
insert into Product(P_no, P_group, P_type, P_program, P_name, P_sal, stock) 
values(7, 'subsciption', 'original', 10, '[Original line] 1일 2식 10일 프로그램', 168000, 9999);
insert into Product(P_no, P_group, P_type, P_program, P_name, P_sal, stock) 
values(8, 'subsciption', 'yummy', 20, '[Yummy line] 맛있어라인 - 1일 2식 20일 프로그램', 319000, 9999);
insert into Product(P_no, P_group, P_type, P_program, P_name, P_sal, stock) 
values(9, 'subsciption', 'yummy', 10, '[Yummy line] 맛있어라인 - 1일 3식 10일 프로그램', 244500, 9999);
insert into Product(P_no, P_group, P_type, P_program, P_name, P_sal, stock) 
values(10, 'subsciption', 'yummy', 4, '[Yummy line] 맛있어라인 - 1일 3식 20일 프로그램', 458000, 9999);
insert into Product(P_no, P_group, P_type, P_program, P_name, P_sal, stock) 
values(11, 'single', 'goguma', 1, '윤식단 생고구마 (3kg/5kg)', 13600, 9999);
insert into Product(P_no, P_group, P_type, P_program, P_name, P_sal, stock) 
values(12, 'single', 'goguma', 1, '모락고구마 (5팩/10팩)', 12000, 9999);
insert into Product(P_no, P_group, P_type, P_program, P_name, P_sal, stock) 
values(13, 'single', 'honest', 1, '[Honest Line | 단품] 어니스트라인 (닭고야)', 19600, 9999);
insert into Product(P_no, P_group, P_type, P_program, P_name, P_sal, stock) 
values(14, 'single', 'taste', 1, '[단품] 맛보기 박스 (랜덤2팩)', 14700, 9999);

select * from Product;