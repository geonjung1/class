package com.green.yphl1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.green.yphl1.dto.Review;
import com.green.yphl1.service.DetailService;
import com.green.yphl1.service.PageBean;
import com.green.yphl1.service.ReviewService;


@Controller
public class DetailController {
	@Autowired
	private DetailService ds;
	private ReviewService rs;
	
	// 상품 상세 페이지
	@GetMapping("detail")
	public String detail() {
		
		return "/detail/detail";
	}
	@GetMapping("detail2")
	public String detail2(){
		
		return "detail/detail2";
	}
	@GetMapping("review")
	public String review(){
		
		return "detail/review";
	}
	
	// 페이징
	/*
	 * @GetMapping("/gu/pageNum/{pageNum}") public String list(Model model, String
	 * pageNum, Review review) { int rowPerPage = 10; if(pageNum == null ||
	 * pageNum.equals("")) pageNum = "1"; int currentPage =
	 * Integer.parseInt(pageNum); int total = rs.getTotal(); int startRow =
	 * (currentPage -1) * rowPerPage + 1; int endRow = startRow + rowPerPage - 1; //
	 * 페이지별 첫번째 게시글 번호 int num = total - startRow + 1; review.setStartRow(startRow);
	 * review.setEndRow(endRow); List<Review> list = rs.list(review); // List<Board>
	 * list = bs.list(startRow, endRow); PageBean pb = new PageBean(currentPage,
	 * rowPerPage, total);
	 * 
	 * 
	 * model.addAttribute("list", list); model.addAttribute("pb", pb);
	 * model.addAttribute("num", num); model.addAttribute("pageNum", pageNum);
	 * model.addAttribute("review", review);
	 * 
	 * 
	 * return "review"; }
	 */
	
	@GetMapping("order")
	public String gu(){
		return "order/order";
	}
}
