package com.green.yphl1.dto;

import lombok.Data;

@Data
public class Order {
	private int order_no;
	private String M_email;
	private String status;
	private String JU_name;
	private String JU_tel;
	private String JU_addr;
	private String JU_addr_detail;
	private String SU_name;
	private String SU_tel;
	private String SU_addr;
	private String SU_addr_detail;
}
