package com.green.yphl1.dao;

import com.green.yphl1.dto.Member;

public interface MemberDao {

	Member select(String u_id);

	int insert(Member member);

}