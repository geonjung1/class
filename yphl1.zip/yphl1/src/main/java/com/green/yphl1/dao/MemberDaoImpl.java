package com.green.yphl1.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.green.yphl1.dto.Member;

@Repository
public class MemberDaoImpl implements MemberDao {
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public Member select(String M_email) {
		return sst.selectOne("memberns.select", M_email);
	}

	@Override
	public int insert(Member member) {
		return sst.insert("memberns.insert", member); // 회원가입
	}
}
