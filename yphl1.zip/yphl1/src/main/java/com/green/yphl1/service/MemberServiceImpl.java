package com.green.yphl1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.green.yphl1.dao.MemberDao;
import com.green.yphl1.dto.Member;

@Service
public class MemberServiceImpl implements MemberService{
	@Autowired
	private MemberDao md;

	@Override
	public Member select(String M_email) {// 회원가입 아이디 중복체크, 로그인할때 사용하는 로직
		return md.select(M_email);
	}

	@Override
	public int insert(Member member) { // 회원가입
		return md.insert(member);
	}
}