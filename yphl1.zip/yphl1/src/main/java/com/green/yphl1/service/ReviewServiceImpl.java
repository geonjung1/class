package com.green.yphl1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.green.yphl1.dao.ReviewDao;
import com.green.yphl1.dto.Review;

@Service
public class ReviewServiceImpl implements ReviewService{
	@Autowired 
	private ReviewDao rd;

	@Override
	public int getTotal() {
		// TODO Auto-generated method stub
		return rd.getTotal();
	}

	@Override
	public List<Review> list(Review review) {
		// TODO Auto-generated method stub
		return rd.list(review);
	}
}
