package com.green.yphl1.dao;

import java.util.List;

import com.green.yphl1.dto.Review;

public interface ReviewDao {

	int getTotal();

	List<Review> list(Review review);

}
