package com.green.yphl1.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.green.yphl1.dto.Review;

@Repository
public class ReviewDaoImpl implements ReviewDao{
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public int getTotal() {
		// TODO Auto-generated method stub
		return sst.selectOne("reviewns.getTotal");
	}

	@Override
	public List<Review> list(Review review) {
		// TODO Auto-generated method stub
		return sst.selectList("reviewns.list", review);
	}
}
