package com.green.yphl1.service;

import java.util.List;

import com.green.yphl1.dto.Review;

public interface ReviewService {

	int getTotal();

	List<Review> list(Review review);


}
