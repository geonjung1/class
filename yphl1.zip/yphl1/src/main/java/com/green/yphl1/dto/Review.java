package com.green.yphl1.dto;

import java.sql.Date;

import lombok.Data;
@Data
public class Review {
	private int RV_no;
    private int RV_star;
    private String RV_content;
    private Date RV_regDate;
    private String del;
    private int P_no;
    private String M_email;
    
    // 페이징 용
    private int startRow;
	private int endRow;
}
