package com.green.yphl1.service;

import com.green.yphl1.dto.Member;

public interface MemberService {

	Member select(String M_email);

	int insert(Member member);

}
