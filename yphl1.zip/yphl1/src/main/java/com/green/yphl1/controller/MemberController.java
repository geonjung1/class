package com.green.yphl1.controller;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.green.yphl1.dto.Member;
import com.green.yphl1.service.MemberService;

@Controller
public class MemberController {
	@Autowired
	private MemberService ms;
	// 임시
		@GetMapping("gu")
		public void gu() {
			
		}
	
	// 회원가입 폼으로 이동
		@RequestMapping("joinForm")
		public String joinForm() {
			return "nolayout/joinForm";
		}
		
		@RequestMapping("loginForm")
		public String loginForm() {
			return "member/loginForm";
		}
		
		@RequestMapping("joinForm2")
		public String joinForm2() {
			return "member/joinForm2";
		}
		@RequestMapping("joinForm3")
		public String joinForm3() {
			return "member/joinForm3";
		}
		// 회원가입 로직
		@RequestMapping("joinResult")
		public String join(Member Member, Model model) {
			int result = 0;
			// form 에서 입력한 member데이터를 가져와서 member2 객체에 대입하여 아이디가 존재하는지 확인
			Member Member2 = ms.select(Member.getM_email());
			if (Member2 == null) {
				result = ms.insert(Member);
			} else {
				result = -1;
			}
			model.addAttribute("result", result);
			return "member/joinResult";
		}
		// 로그인
		@RequestMapping("loginResult")
		public String login(String prevUrl, Member Member, Model model, HttpSession session) {
			// memberDB ; DB 데이터
			Member MemberDB = ms.select(Member.getM_email());
			int result = 0; // 암호가 일치하지 않는 경우
			if (MemberDB == null) {
				result = -1; // DB에 없는 아이디
			} else if (MemberDB.getDel().equals("Y"))
				result = -1; // DB에 없는 아이디
			else if (MemberDB.getM_password().equals(Member.getM_password())) {
				result = 1;
				session.setAttribute("U_email", Member.getM_email());	//header출력용
			}
			model.addAttribute("result", result);
			model.addAttribute("prevUrl", prevUrl);
			return "member/loginResult";
		}
		// 로그 아웃
		@RequestMapping("logout")
		public String logout(HttpSession session) {
			session.invalidate();
			return "member/logout";
		}
		
}
