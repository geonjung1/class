package com.green.yphl1.dto;

import java.sql.Date;
import org.springframework.web.multipart.MultipartFile;
import lombok.Data;

@Data
public class Member {
	private String M_email;
	private String M_name;
	private String M_tel;
	private String M_password;
	private String M_img;
	private Date M_birth;
	private String M_addr;
	private String M_addr_detail;
	private Date join_date;
	private String del;
	private String recommend_code;
	private int mileage;
	
	// 업로드
    private MultipartFile file;
}