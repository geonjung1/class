package com.green.yphl1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.green.yphl1.dao.DetailDao;

@Service
public class DetailServiceImpl implements DetailService{
	@Autowired
	private DetailDao dd;

	
}
