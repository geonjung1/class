package com.green.yphl1.dao;

public interface DetailDao {

}
