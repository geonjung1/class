package com.green.yphl1.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class DetailDaoImpl implements DetailDao{
	@Autowired
	private SqlSessionTemplate sst;


}
