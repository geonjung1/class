package com.green.yphl1.service;

public interface DetailService {

}
